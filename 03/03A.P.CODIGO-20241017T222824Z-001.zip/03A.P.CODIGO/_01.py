class NombreDeLaClase:  
    # Atributos y métodos
    pass