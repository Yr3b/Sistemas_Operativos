class Persona:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad

# Crear una instancia de la clase Persona
#   (es decir, crear un objeto)
persona1 = Persona("Ana", 25)
