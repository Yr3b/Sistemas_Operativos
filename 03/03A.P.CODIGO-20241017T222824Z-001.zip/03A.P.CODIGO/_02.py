class NombreDeLaClase:  
    def __init__(self):
        # Código del constructor
        pass
