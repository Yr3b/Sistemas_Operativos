class Auto:    
    # . . . . .
    # contructor ..
    # . . . . .

    # Métodos públicos para interactuar 
    #    con el auto

    def acelerar(self, cantidad):
        self._velocidad += cantidad
        self._mostrar_estado()

    # . . . . .
