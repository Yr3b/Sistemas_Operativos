class Vehiculo:        # Superclase
    pass

class Auto(Vehiculo):  # Subclase
    pass