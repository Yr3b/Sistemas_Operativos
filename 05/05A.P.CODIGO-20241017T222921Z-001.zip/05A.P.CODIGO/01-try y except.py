a=10
b=0
try:
    res=a/b
    print(res)
except :
    print("Error, no se puede dividir por cero" )